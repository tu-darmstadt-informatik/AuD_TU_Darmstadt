package lab;

import java.util.Random;

/**
 * Aufgabe H1c)
 * 
 * Abgabe von: <name>, <name> und <name>
 */

/**
 * Use a random pivot within Quick Sort.
 */
public class HybridSortRandomPivot extends HybridSort {
	// TODO: Implement 
	
}
