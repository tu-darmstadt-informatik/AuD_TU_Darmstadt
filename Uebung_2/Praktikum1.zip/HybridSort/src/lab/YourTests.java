package lab;

/**
 * Aufgabe H1
 * 
 * Abgabe von: <name>, <name> und <name>
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Use this class to implement your own tests.
 */
class YourTests {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
